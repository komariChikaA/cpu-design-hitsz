# Windows：带 Cache 的流水线 CoreMark 下板流程

本包用于 Windows 10/11 + Vivado 2023.2 + EGO1。

工程已经预装正式 CoreMark 镜像，不需要 Linux 服务器，也不需要重新编译 C 程序：

- CPU：五级流水线 RV32IM，50 MHz；
- ICache：64 line、direct-mapped、16-byte line；
- DCache：64 line、direct-mapped、16-byte line；
- DCache 策略：write-through、no-write-allocate；
- Cache refill：AXI INCR burst，`ARLEN=3`，共 4 个 32-bit beat；
- MMIO：`0xFFFF_xxxx` 强制 Uncached；
- CoreMark：700 次迭代；
- 学号：`2024311081_2024311453`。

## 1. 解压位置

建议解压到短的纯英文路径，例如：

```text
C:\fpga\miniRV_pipeline_axi_ego1
```

不要覆盖以前的无 Cache 工程，也不要在压缩包内部直接打开 `miniRV.xpr`。

## 2. 先运行 Windows 校验

双击：

```text
verify_cache_coremark_windows.cmd
```

或者在 PowerShell 中执行：

```powershell
.\verify_cache_coremark_windows.cmd
```

末尾必须看到：

```text
PASS: ICache and DCache are enabled
PASS: cpu_top instantiates both caches
PASS: AXI cache-line burst refill is present
Windows Cache CoreMark package verification passed.
```

## 3. 生成新的 Cache 版 bitstream

### 方法 A：Vivado 图形界面

1. 使用 Vivado 2023.2 打开本包的 `miniRV.xpr`。
2. 打开底部 **Tcl Console**。
3. 执行：

```tcl
source rebuild_ego1.tcl
```

4. 等到控制台明确出现：

```text
EGO1 build finished.
```

### 方法 B：Windows 批处理

如果 Vivado 已加入 `PATH`，双击：

```text
build_cache_coremark_windows.cmd
```

该脚本会打开本包工程并执行同一个 `rebuild_ego1.tcl`。

构建完成后必须检查：

```text
WNS >= 0
TNS = 0
Number of Failing Endpoints = 0
```

必须烧录这次新生成的文件：

```text
outputs\vivado\miniRV_pipeline_axi_ego1.bit
```

不能沿用之前普通流水线或无 Cache CoreMark 的 `.bit`。`main.mem` 会在生成 bitstream
时固化到 IROM/DRAM Block RAM 中，单独复制 `main.mem` 不会改变旧 `.bit`。

## 4. Windows 串口记录

先在“设备管理器 → 端口 (COM 和 LPT)”中确认板卡串口，例如 `COM5`。

在工程目录打开 PowerShell：

```powershell
powershell -ExecutionPolicy Bypass -File .\capture_coremark_serial.ps1 -Port COM5
```

参数是实际端口号。脚本使用：

```text
115200 baud
8 data bits
no parity
1 stop bit
no flow control
```

串口内容会显示在窗口中，同时保存为：

```text
coremark_uart_YYYYMMDD_HHMMSS.log
```

CoreMark 不需要键盘输入。开始记录后，按下并松开板卡 `S6 RST`；不要按 `S5 PROG#`。

也可以使用 PuTTY、Tera Term 或 MobaXterm，参数同样是 `115200 8N1`、Flow control
设为 `None`、Local echo 设为 `Off`。

## 5. 正确运行时应该看到

启动阶段：

```text
LED：C001
数码管：C0010000
```

串口开头：

```text
miniRV Pipeline AXI EGO1 CoreMark
Student IDs: 2024311081_2024311453
CPU clock: 50 MHz
CoreMark 1.0
```

700 次迭代需要等待，不要中途复位。最终必须同时出现：

```text
Iterations       : 700
Correct operation validated. See README.md for run and reporting rules.
CoreMark 1.0 :
CoreMark/MHz :
FINISH
```

板卡最终状态：

```text
LED：C0A5
数码管：C0DE600D
```

出现 CRC `ERROR!`、`Errors detected`、`Cannot validate operation`、`E0xx`，
或者没有到达 `FINISH`，都不能记为通过。

## 6. 必须保存和拍照

1. Vivado 构建完成与 Timing Summary：拍到 WNS、TNS、失败端点数；
2. 串口开头：拍到标题、两位学号和 `CPU clock: 50 MHz`；
3. 串口结尾：拍到 700 次、`Correct operation validated`、分数、
   `CoreMark/MHz` 和 `FINISH`；
4. 板卡近照：拍清 LED `C0A5` 与数码管 `C0DE600D`。

同时保存：

```text
outputs\vivado\miniRV_pipeline_axi_ego1.bit
outputs\vivado\timing_summary.rpt
outputs\vivado\utilization.rpt
outputs\vivado\implementation_drc.rpt
coremark_uart_YYYYMMDD_HHMMSS.log
```

本地包校验只能证明工程、镜像和 RTL 结构正确；Windows Vivado 的实际综合、时序收敛和
EGO1 实板结果必须以你这次生成的报告、串口日志和照片为准。
